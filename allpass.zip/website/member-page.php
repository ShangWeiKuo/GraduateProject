<?php include("part/header.php"); ?>
<body>
    <div id="main">
        <div class="wrapper">
            <?php include("part/sidebar.php"); ?> 
            <div id="content" class="member-page-content">
                <?php include("content/member-page-content.php"); ?>
            </div>
        </div>
    </div>
</body>

<?php include("part/footer.php"); ?> 