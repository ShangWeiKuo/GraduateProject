<?php include("part/backend-header.php"); ?>
<body>
    <div id="main">
        <div class="wrapper">
            <?php include("part/sidebar.php"); ?> 
            <div id="content">
                <?php include("content/member-timetable-content.php"); ?>
            </div>
        </div>
    </div>
</body>

<?php include("part/backend-footer.php"); ?>