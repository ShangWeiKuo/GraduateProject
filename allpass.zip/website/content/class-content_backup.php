<?php include_once("part/sql-connection.php"); ?>
<?php include_once('function/token.php') ?>
<script>
    function reply(id){
        var elem = document.getElementById('reply_' + id);
        elem.style.display = (elem.style.display === 'none' ? 'block' : 'none');
    }
    function delete_q(id, t){
        if(confirm('確定要刪除這則評論？')){
            window.location = 'question-delete.php?qid=' + id + '&token=' + t <?php if(isset($_GET['cid'])){ echo '+ \'&ref='.$_GET['cid'].'\'';} ?>;
        }
    }
    function delete_a(id, t){
        if(confirm('確定要刪除這則回應？')){
            window.location = 'answer-delete.php?aid=' + id + '&token=' + t <?php if(isset($_GET['cid'])){ echo '+ \'&ref='.$_GET['cid'].'\'';} ?>;
        }
    }
</script>

<?php
    $stmt = $conn->prepare('SELECT c_id, c_name, c_type, c_time, c_classroom, t_name, c_info, c_code, c_credit, c_lang, c_lang_sec FROM class_info WHERE c_id = ?');
    $stmt->bind_param('d', $_GET['cid']);
    mysqli_stmt_execute($stmt);
    $r_t = '';
    mysqli_stmt_bind_result($stmt, $r_c_id, $r_c_name, $r_c_type, $r_t, $r_c_cr, $r_t_name, $r_c_info, $r_c_code, $r_c_cd, $r_c_lang, $r_c_lang_s);
    mysqli_stmt_fetch($stmt);
    $stmt->close();
    $stmt = $conn->prepare('SELECT concat(ct_name, "：", ct_name_sec) FROM class_type WHERE ct_id = ?');
    $stmt->bind_param('d', $r_c_type);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $c_type);
    mysqli_stmt_fetch($stmt);
    $stmt->close();
    // binary data to day
    function binary_to_day($bdata){
        $t = array('X', '1', '2', '3', '4', 'Y', '5', '6', '7', '8', '9', '10', '11', '12', '13');
        $time_str = '';
        $i = 0;
        $comma = false;
        for($i=0; $i<15; $i++){
            if(($bdata & 2**$i) !== 0){
                if($comma){
                    $time_str = $time_str.', ';
                }
                $time_str = $time_str.$t[$i];
                $comma = true;
            }
        }
        return $time_str;
    }
?>

<div class="container class-content">
    <h5 style='font-weight: bold;'>
        <?php echo $r_c_name; ?>
    </h5>
    <div style='margin-top: 24px; margin-left: 24px;'>
        <table width="50%">
            <tr>
                <td style="font-weight: bold;">課程編號</td>
                <td><?php echo $r_c_code; ?></td>
            </tr>
            <tr>
                <td style="font-weight: bold;">學分數</td>
                <td><?php echo $r_c_cd; ?></td>
            </tr>
            <tr>
                <td style="font-weight: bold;">上課時間</td>
                <td>
                <?php 
                    echo $r_t;
                    /*
                    $new_data = '';
                    $day = array('一', '二', '三', '四', '五', '六', '日');
                    $semicolon = false;
                    for($i=0; $i<7; $i++){
                        if($r_t[$i] !== 0){
                            if($semicolon){
                                echo '　';
                            }
                            echo $day[$i].' '.binary_to_day($r_t[$i]);
                            $new_data .= $day[$i].' '.binary_to_day($r_t[$i]);
                            $semicolon = true;
                        }
                    }
                    $stmt = $conn->prepare('UPDATE class_info SET c_time = ? WHERE c_id = ?');
                    $stmt->bind_param('sd', $new_data, $_GET['cid']);
                    mysqli_stmt_execute($stmt);
                    $stmt->close();
                    */
                ?>
                </td>
            </tr>
            <tr>
                <td style="font-weight: bold;">上課教室</td>
                <td><?php echo $r_c_cr; ?></td>
            </tr>
            <tr>
                <td style="font-weight: bold;">課程分類</td>
                <td><?php echo '<a href="./class-list.php?ct='.$r_c_type.'">'.$c_type.'</a>'; ?></td>
            </tr>
            <tr>
                <td style="font-weight: bold;">授課教師</td>
                <td>
                <?php
                    $n_list = explode('、', $r_t_name);
                    for($i=0; $i<count($n_list)-1; $i++){
                        echo '<a href="./teacher-info.php?tname='.$n_list[$i].'">'.$n_list[$i].'</a>、';
                    }
                    echo '<a href="./teacher-info.php?tname='.$n_list[$i].'">'.$n_list[$i].'</a>';
                ?>
                </td>
            </tr>
            <tr>
                <td style="font-weight: bold;">主要授課語言</td>
                <td><?php echo $r_c_lang; ?></td>
            </tr>
            <tr>
                <td style="font-weight: bold;">次要授課語言</td>
                <td><?php echo $r_c_lang_s; ?></td>
            </tr>
        </table>
    </div>	
    <div>
        <ul id="tabs-swipe-demo" class="tabs" style="margin-top: 48px;">
            <li class="tab col s3 class-tab "><a href="#test-swipe-1">課程概述</a></li>
            <li class="tab col s3 class-tab "><a href="#test-swipe-2">評論</a></li>
            <li class="tab col s3 class-tab "><a href="#test-swipe-3">檔案</a></li>
        </ul>
        <div id="test-swipe-1" >
            <table id="comments-area" class="striped" width="50%">
                <?php
                    echo '<tr><td>';
                    echo '<p style="margin: 24px;">';
                    echo $r_c_info;
                    echo '</p>';
                    echo '</td></tr>';
                    /*
                    if(isset($_GET['cid'])){
                        $stmt->close();
                        $stmt = mysqli_prepare($conn, "SELECT c.com_id, c.m_id, c.c_id, c.com_content, m.m_account, m.m_name, c.com_time FROM comment c JOIN member m ON c.m_id = m.m_id WHERE c_id = ? ORDER BY com_id DESC");
                        $stmt->bind_param('d', $_GET['cid']);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_bind_result($stmt, $r0, $r1, $r2, $r3, $r4, $r5, $r6);
                        while(mysqli_stmt_fetch($stmt)){
                            echo '<tr>';
                            echo '<td>';
                            echo '<p><span style="margin-left: 24px; margin-right: 8px; font-weight: bold; float: left;">';
                            echo $r5.'（'.$r4.'）';
                            echo '</span>';
                            echo '<span style="margin-left: 24px; margin-right: 24px; float: right;">';
                            echo $r6;
                            echo '</span></p>';
                            echo '<p style="margin-left: 36px; margin-right: 24px; margin-top: 48px;">';
                            echo $r3;
                            echo '</p>';
                            if(isset($_SESSION['account'])){
                                echo '<p style="margin-top: -8px; margin-right: 24px; float: right;">';
                                echo '<a class="waves-effect waves-light btn" href="#">檢舉</a>';
                                echo '</p>';
                            }
                            echo '</tr>';
                        }
                    }
                    */
                ?>
                <?php
                    //if(isset($_SESSION['account'])){
                ?>
                    <!--
                        <tr>
                            <td>
                                <form action="comment-post.php" method="POST">
                                    <div style="margin-left: 16px; margin-right: 16px;">
                                        <input type="text" name="content" placeholder="發表評論..." style="display: inline;"/>
                                        <input name="cid" value=<?php //if(isset($_GET['cid'])){echo '"'.$_GET['cid'].'"';} ?> hidden/>
                                        <input type="submit" hidden/> 
                                    </div>
                                </form>
                            </td>
                        </tr>
                    -->
                <?php
                    //}
                ?>
            </table>
        </div>
        <div id="test-swipe-2" >
            <table class="striped" width="50%">
                <?php
                    if(isset($_GET['cid'])){
                        $stmt->close();
                        $stmt = mysqli_prepare($conn, "SELECT q.q_id, q.m_id, q.c_id, q.q_content, m.m_account, m.m_name, q.q_time FROM question q JOIN member m ON q.m_id = m.m_id WHERE c_id = ? AND q_delete = 0 ORDER BY q_id DESC");
                        $stmt->bind_param('d', $_GET['cid']);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_bind_result($stmt, $r0, $r1, $r2, $r3, $r4, $r5, $r6);
                        $qdata = array();
                        while(mysqli_stmt_fetch($stmt)){
                            $qdata[] = array($r0, $r1, $r2, $r3, $r4, $r5, $r6);
                        }
                        $stmt->close();
                        for($i=0; $i<count($qdata); $i++){
                            echo '<tr>';
                            echo '<td>';
                            echo '<div>';
                            echo '<span style="margin-top: 8px; margin-left: 24px; margin-right: 8px; font-weight: bold; float: left;">';
                            echo $qdata[$i][5].'（'.$qdata[$i][4].'）';
                            echo '</span>';
                            echo '<span style="margin-left: 24px; margin-right: 24px; float: right;">';
                            echo $qdata[$i][6];
                            echo '</span>';
                            echo '</div>';
                            echo '</div>';
                            echo '<p style="margin-left: 36px; margin-right: 24px; margin-top: 48px;">';
                            echo $qdata[$i][3];
                            echo '</p>';
                            echo '</div>';
                            echo '<div style="margin-left: 36px; margin-right: 36px;">';
                            $stmt = mysqli_prepare($conn, "SELECT a.a_id, a.m_id, a.a_content, m.m_name, m.m_account FROM answer a JOIN member m ON a.m_id = m.m_id WHERE q_id = ? AND a.a_delete = 0");
                            $stmt->bind_param('d', $qdata[$i][0]);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_bind_result($stmt, $r0, $r1, $r2, $r3, $r4);
                            echo '<p style="clear: both; border-bottom: 1px dotted #999999; float: none; margin-bottom: 12px; padding-top: 12px;"></p>';
                            while(mysqli_stmt_fetch($stmt)){
                                echo '<p style="margin-top: -4px;">';
                                echo '<span style="font-weight: bold;">'.$r3.'（'.$r4.'）</span>：'.$r2;
                                echo '</p>';
                            }
                            echo '</div>';
                            if(isset($_SESSION['account'])){
                                echo '<div>';
                                echo '<p style="clear: both;">';
                                if($qdata[$i][4] !== $_SESSION['account']){
                                    //echo '<a class="waves-effect waves-light btn" style="margin-right: 24px; float: right;" href="#">檢舉</a>';
                                    echo '<a class="waves-effect waves-light btn" style="margin-right: 12px; float: right;" onclick="reply('.$qdata[$i][0].');">回應</a>';
                                }else{
                                    echo '<a class="waves-effect waves-light btn" style="margin-right: 24px; float: right;" onclick="delete_q('.$qdata[$i][0].', \''.$token.'\');">刪除</a>';
                                    echo '<a class="waves-effect waves-light btn" style="margin-right: 12px; float: right;" onclick="reply('.$qdata[$i][0].');">回應</a>';
                                }
                                echo '</p>';
                                echo '</div>';
                                echo '<form action="answer-post.php" method="POST">';
                                echo '<div style="padding: 12px; display: none;" id="reply_'.$qdata[$i][0].'">';
                                //echo '<p style="clear: both; border-bottom: 1px dotted #999999; float: none; margin-bottom: 12px; padding-top: 12px;"></p>';
                                echo '<input type="text" name="content" placeholder="發表回應..." style="width: 80%; margin-left: 24px; clear:both; float: left;" required/>';
                                echo '<input type="submit" class="waves-effect waves-light btn" href="#" style="float: right; margin-right: 24px; margin-top: 12px;" value="送出">';
                                echo '<input name="qid" value="'.$qdata[$i][0].'" hidden/>';
                                echo '<input name="cid" value="'.$_GET['cid'].'" hidden/>';
                                echo '</div>';
                                echo '</form>';
                            }
                            echo '</td>';
                            echo '</tr>';
                        }
                    }
                ?>
                <?php
                    if(isset($_SESSION['account'])){
                ?>
                        <tr>
                            <td>
                                <form action="question-post.php" method="POST">
                                    <div style="margin-left: 16px; margin-right: 16px;">
                                        <input type="text" name="content" placeholder="發表評論..." style="display: inline; width: 80%;" required/>
                                        <input name="cid" value=<?php if(isset($_GET['cid'])){echo '"'.$_GET['cid'].'"';} ?> hidden/>
                                        <input type="submit" class="waves-effect waves-light btn" href="#" style="float: right; margin-right: 12px; margin-top: 12px;" value="送出"> 
                                    </div>
                                </form>
                            </td>
                        </tr>
                <?php
                    }
                ?>
            </table>
        </div>
        <div id="test-swipe-3" >
            <table class="striped" width="50%">
                <tr>
                    <td>
                        <p style="margin-left: 24px; margin-right: 8px; font-weight: bold;">
                            桐谷和人
                        </p>
                        <p style="margin-left: 36px; margin-right: 24px;">
                            <i class="material-icons">file_download</i>
                            星爆氣流斬招式詳解.pdf
                        </p>
                        <p style="margin-right: 24px; margin-top: -8px; float: right;">
                            <a class="waves-effect waves-light btn" href="#">檢舉</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin-left: 24px; margin-right: 8px; font-weight: bold;">
                            星爆俠
                        </p>
                        <p style="margin-left: 36px; margin-right: 24px;">
                            <i class="material-icons">file_download</i>
                            第七十四層之魔物特性分析.pptx
                        </p>
                        <p style="margin-right: 24px; margin-top: -8px; float: right;">
                            <a class="waves-effect waves-light btn" href="#">檢舉</a>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin-left: 24px; margin-right: 8px; font-weight: bold;">
                            黃宏成台灣阿成世界偉人財神總統
                        </p>
                        <p style="margin-left: 36px; margin-right: 24px;">
                            <i class="material-icons">file_download</i>
                            財神到我家大門口.pptx
                        </p>
                        <p style="margin-right: 24px; margin-top: -8px; float: right;">
                            <a class="waves-effect waves-light btn" href="#">檢舉</a>
                        </p>
                    </td>
                </tr>
                <tr></tr>
                <tr></tr>
            </table>
            <table width="50%">
                <tr>
                    <td>
                        <input type="text" value="D:\驅動程式\GTX1080顯示卡驅動程式安裝方法.mkv" readonly/>
                    </td>
                    <td style="width: 0%;">
                        <p style="margin-top: -8px; float: right;">
                            <a class="waves-effect waves-light btn-large" href="#">選擇檔案…</a>
                            <a class="waves-effect waves-light btn-large" href="#">上傳</a>
                        </p>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>