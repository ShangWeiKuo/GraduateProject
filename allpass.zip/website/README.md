# AllPass

http://allpass.info/


## 提交完後請待主分支合併後在pull更新繼續工作


## 調用

 頁首

```
<?php include("part/header.php"); ?>
```




 頁尾
 

```
<?php include("part/footer.php"); ?>
```




## 資料夾說明 

content -- 調用內容
<br>
part    -- 主要部件
<br>
source  -- 資源 (css/font/img/js)


## 檔案

任何檔案網頁連結請使用相對路徑!!!


style.css -- 主要樣式表
<br>
請勿直接修改 materialize.min.css 樣式表，請透過寫入 style.css 使用 !important 取代
範例參考
```
.input-field label{
    -webkit-transform: none !important;
}
```

<br>
Google Icon 圖示 
https://material.io/icons/ 
<br>
Materializecss 框架
http://materializecss.com
