<footer class="page-footer cyan lighten-1">
    <div class="container">
        <div class="row">
            <div class="col l4 s12">
               <ul>
                    <a href="https://page.line.me/jtq4380e">
                        <img src="./source/img/ad1.jpg" style="width: auto; height: auto; max-width: 100%; max-height: 100%;">
                    </a>
               </ul>
            </div>
            <div class="col l4 s12">
               <ul>
                    <a href="https://page.line.me/jtq4380e">
                        <img src="./source/img/ad2.jpg" style="width: auto; height: auto; max-width: 100%; max-height: 100%;">
                    </a>
               </ul>
            </div>
            <div class="col l4 s12">
               <ul>
                    <a href="https://page.line.me/jtq4380e">
                        <img src="./source/img/ad3.jpg" style="width: auto; height: auto; max-width: 100%; max-height: 100%;">
                    </a>
               </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
        All Pass，提供學生通識課程交流。Connect us: <a href="mailto:admin@allpass.info" style='color: #FFFFFF'>admin@allpass.info</a>
        </div>
    </div>
</footer>

<!-- Compiled and minified JavaScript -->

<script src="./source/js/jquery-3.2.1.min.js"></script>
<script src="./source/js/materialize.min.js"></script>
<script src="./source/js/plugins.js"></script>
<script src="./source/js/init.js"></script>
<script src="./source/js/perfect-scrollbar.min.js"></script>

