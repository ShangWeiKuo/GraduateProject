<header id="header" class="page-topbar">
    <!-- start header nav-->
    <div class="navbar-fixed ">
        <nav class="navbar-color">
            <div class="nav-wrapper cyan lighten-1">
                <ul class="left">
                    <li>
                        <h1 class="logo-wrapper">
                            <a href="./" class="brand-logo darken-1">AllPass</a>
                        </h1>
                    </li>
                </ul>
                <div class="header-search-wrapper hide-on-med-and-down">
                    <i class="material-icons">search</i>
                    <form action="teacher-info.php" method="GET">
                        <input type="text" name="tname" class="header-search-input z-depth-2" placeholder="課程名稱、課程代號、老師">
                    </form>
                </div>
            </div>
        </nav>
    </div>
	
</header>
 <form action="teacher-info.php" class="mobile_serach" method="GET">
<input type="text" name="tname" id="mobile_serach_input" class="header-search-input z-depth-2" placeholder=" 課程名稱、課程代號、老師" 
style="border-bottom: 0px!important;background: #fff;text-align: center;"> 
<button>  <i class="material-icons search_icon">search</i> </button>
 </form>
 
