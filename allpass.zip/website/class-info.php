<?php include("part/header.php"); ?>
<body>
    <div id="main">
        <div class="wrapper">
            <?php include("part/sidebar.php"); ?>
            <div class="row class-info-box">
                <?php include("content/class-content.php"); ?>
            </div>
        </div>
    </div>
</body>

<?php include("part/footer.php"); ?> 