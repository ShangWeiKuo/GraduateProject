<?php include("part/header.php"); ?>

<body>
    <div id="main">
        <div class="wrapper">
            <?php include("part/sidebar.php"); ?> 
            <div id="content">
                <?php include("content/index-content.php"); ?> 
            </div>
        </div>
    </div>
</body>

<?php include("part/footer.php"); ?> 